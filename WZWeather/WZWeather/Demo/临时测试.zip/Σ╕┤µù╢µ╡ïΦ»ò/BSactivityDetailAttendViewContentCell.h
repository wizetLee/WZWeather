//
//  BSactivityDetailAttendViewContentCell.h
//  
//
//  Created by admin on 8/3/18.
//

#import "BSactivityDetailAttendViewBaseCell.h"

@interface BSactivityDetailAttendViewContentCell : BSactivityDetailAttendViewBaseCell

@end
