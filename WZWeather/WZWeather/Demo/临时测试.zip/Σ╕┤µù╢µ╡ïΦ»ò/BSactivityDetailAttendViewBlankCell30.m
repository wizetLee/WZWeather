//
//  BSactivityDetailAttendViewBlankCell30.m
//  WZWeather
//
//  Created by admin on 8/3/18.
//  Copyright © 2018年 WZ. All rights reserved.
//

#import "BSactivityDetailAttendViewBlankCell30.h"

@implementation BSactivityDetailAttendViewBlankCell30

- (float)calculateCellHeightWithModel:(id)model {
    return 11;
}
@end
