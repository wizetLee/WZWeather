//
//  BSactivityDetailAttendViewBlankCell50.m
//  WZWeather
//
//  Created by admin on 8/3/18.
//  Copyright © 2018年 WZ. All rights reserved.
//

#import "BSactivityDetailAttendViewBlankCell50.h"

@implementation BSactivityDetailAttendViewBlankCell50

- (float)calculateCellHeightWithModel:(id)model {
    return 21.5;
}

@end
