//
//  BSactivityDetailAttendViewBlankCell.m
//  WZWeather
//
//  Created by admin on 8/3/18.
//  Copyright © 2018年 WZ. All rights reserved.
//

#import "BSactivityDetailAttendViewBlankCell.h"
#import "BSactivityDetailAttendViewTableModel.h"

@implementation BSactivityDetailAttendViewBlankCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
    }
    return self;
}

- (void)updateWithModel:(BSactivityDetailAttendViewTableModel *)model {
    
}

- (float)calculateCellHeightWithModel:(BSactivityDetailAttendViewTableModel *)model {
    
    return 0;
}
@end
