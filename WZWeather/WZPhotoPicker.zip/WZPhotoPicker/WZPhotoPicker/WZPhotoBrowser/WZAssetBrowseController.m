//
//  WZAssetBrowseController.m
//  WZPhotoPicker
//
//  Created by wizet on 2017/6/2.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "WZAssetBrowseController.h"

@interface WZAssetBrowseController ()

@end

@implementation WZAssetBrowseController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


- (void)createViews {
   
}

#pragma mark Match image
- (void)matchThumnailImageWith:(WZImageContainerController *)VC {
    if (!VC) {
        return;
    }
    
    NSUInteger index = VC.integer_index;
    
//    if (index < _array_mediaAsset.count ) {
//        WZMediaAsset *asset = _array_mediaAsset[index];
//        if (asset.image_thumbnail) {
//            [VC matchingPicture:asset.image_thumbnail];
//        } else {
//            [WZMediaPicker fetchThumbnailWith:asset.asset synchronous:false handler:^(UIImage *thumbnail) {
//                asset.image_thumbnail = thumbnail;
//                [VC matchingPicture:asset.image_thumbnail];
//            }];
//        }
//        
//        //        VC.button_browseOrigion.hidden = false;
//    }
}

- (void)matchOrigionImageWith:(WZImageContainerController *)VC {
    if (!VC) {
        return;
    }
    NSUInteger index = VC.integer_index;
    WZMediaAsset *asset = nil;
//    if (index < _array_mediaAsset.count ) {
//        
//        asset = _array_mediaAsset[index];
//        if (asset.url_media) {
//            //网络图片路径
//            //直接使用 SD  抛出进度
//            if (!_imageView_medium) {
//                _imageView_medium = [[UIImageView alloc] init];
//            }
//            //cancel之前的下载
//            [_imageView_medium sd_cancelCurrentImageLoad];
//            [_imageView_medium sd_setImageWithPreviousCachedImageWithURL:asset.url_media andPlaceholderImage:nil options:SDWebImageRetryFailed progress:^(NSInteger receivedSize, NSInteger expectedSize) {
//                //                VC中的加载动作
//            } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
//                [VC matchingPicture:image];
//            }];
//            
//        } else if (asset.string_origionPath || asset.image_origion) {
//            if (asset.image_origion) {
//                [VC matchingPicture:asset.image_origion];
//            } else {
//                UIImage *image = [UIImage imageWithContentsOfFile:asset.string_origionPath];
//                [VC matchingPicture:image];
//            }
//        } else if (asset.asset) {
//            //根据 PHAsset callback
//            //block回调可能会引起图片紊乱  请求前先将之前的request cancel掉
//            [[PHImageManager defaultManager] cancelImageRequest:_imageRequestID];
//            
//            //            if (asset.showOrigion) {
//            //                _imageRequestID = [WZMediaPicker fetchOrigionWith:asset.asset synchronous:false handler:^(UIImage *origion) {
//            //                    //图片有时候像素太高 渲染成本太高 作判断压缩降低成本
//            //                    [VC matchingPicture:origion];
//            //                }];
//            //            } else {
//            _imageRequestID = [WZMediaPicker fetchImageWith:asset.asset costumSize:CGSizeMake(2000, 2000) synchronous:false handler:^(UIImage *image) {
//                //                asset.image_origion = image;//不作缓存
//                [VC matchingPicture:image];
//            }];
//            //            }
//        }
//    }
    
    //配置其他的属性
    self.custom_navigation.label_title.text = [NSString stringWithFormat:@"当前页面ID:%ld", index];
    self.mediaAsset_current = asset;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
