//
//  WZImagesBrowseToolView.m
//  WZPhotoPicker
//
//  Created by admin on 17/6/1.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "WZImagesBrowseToolView.h"

@implementation WZImagesBrowseToolView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self createViews];
    }
    return self;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.frame = CGRectZero;
        [self createViews];
    }
    return self;
}

- (void)createViews {
    _button_left = [UIButton buttonWithType:UIButtonTypeCustom];
    [_button_left addTarget:self action:@selector(clickedBtn:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)setFrame:(CGRect)frame {
    CGFloat toolHeight = 50.0;
    [super setFrame:CGRectMake(0.0, [UIScreen mainScreen].bounds.size.height - toolHeight, [UIScreen mainScreen].bounds.size.width, toolHeight)];
}

@end
