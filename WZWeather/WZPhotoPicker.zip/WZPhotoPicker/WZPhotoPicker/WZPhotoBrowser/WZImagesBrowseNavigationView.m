//
//  WZImagesBrowseNavigationView.m
//  WZPhotoPicker
//
//  Created by admin on 17/6/1.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "WZImagesBrowseNavigationView.h"

@implementation WZImagesBrowseNavigationView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self createViews];
    }
    return self;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [self createViews];
    }
    return self;
}

- (void)createViews {
    self.backgroundColor = [[UIColor lightGrayColor] colorWithAlphaComponent:0.4];
    
    CGFloat buttonHW = 44.0;
    _button_left = [[UIButton alloc] initWithFrame:CGRectMake(0.0, 20.0, buttonHW, buttonHW)];
    _button_right = [[UIButton alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width - buttonHW, 20.0, buttonHW, buttonHW)];
    _label_title = [[UILabel alloc] initWithFrame:CGRectMake(buttonHW, 20.0, [UIScreen mainScreen].bounds.size.width - buttonHW * 2.0, buttonHW)];
    [self addSubview:_button_right];
    [self addSubview:_button_left];
    [self addSubview:_label_title];
    
    _label_title.textAlignment = NSTextAlignmentCenter;
    [_button_left setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_button_right setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_button_left setTitle:@"返回" forState:UIControlStateNormal];
    [_button_right setTitle:@"选中" forState:UIControlStateNormal];
    _label_title.text = @"图片";
    [_button_right addTarget:self action:@selector(clickedBtn:) forControlEvents:UIControlEventTouchUpInside];
    [_button_left addTarget:self action:@selector(clickedBtn:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)setFrame:(CGRect)frame {
    [super setFrame:CGRectMake(0.0, 0.0, [UIScreen mainScreen].bounds.size.width, 64.0)];
}

- (void)clickedBtn:(UIButton *)sender {
    if (sender == _button_left) {
        if ([_delegate respondsToSelector:@selector(leftButtunAction)]) {
            [_delegate leftButtunAction];
        }
    } else if (sender == _button_right) {
        if ([_delegate respondsToSelector:@selector(rightButtunAction)]) {
            [_delegate rightButtunAction];
        }
    }
}



@end
