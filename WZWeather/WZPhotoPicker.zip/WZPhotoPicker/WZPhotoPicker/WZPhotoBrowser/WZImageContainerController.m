//
//  WZImageContainerController.m
//  WZPhotoPicker
//
//  Created by admin on 17/5/24.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "WZImageContainerController.h"

@interface WZImageContainerController()

@property (nonatomic, strong) WZImageScrollView *scroll_picture;

@end

@implementation WZImageContainerController

- (instancetype)init
{
    self = [super init];
    if (self) {
        _scroll_picture = [[WZImageScrollView alloc] init];
        [self.view addSubview:_scroll_picture];
        
        _button_browseOrigion = [UIButton buttonWithType:UIButtonTypeCustom];
        [_button_browseOrigion setTitle:@"浏览原图" forState:UIControlStateNormal];
        [_button_browseOrigion setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
        [_button_browseOrigion addTarget:self action:@selector(clickedBtn:) forControlEvents:UIControlEventTouchUpInside];
        CGSize size_browse = CGSizeMake(200.0, 44.0);
        _button_browseOrigion.frame = CGRectMake(([UIScreen mainScreen].bounds.size.width - size_browse.width) / 2.0, [UIScreen mainScreen].bounds.size.height - 100.0, size_browse.width, size_browse.height);
        [self.view addSubview:_button_browseOrigion];
    }
    return self;
}

- (void)clickedBtn:(UIButton *)sender {
    if ( [_delegate respondsToSelector:@selector(imageContainerController:browseOrigionInIndex:)]) {
        [_delegate imageContainerController:self browseOrigionInIndex:self.integer_index];
    }
}

- (void)setVC_main:(UIViewController *)VC_main {
    if ([VC_main isKindOfClass:[UIViewController class]]) {
        _VC_main = VC_main;
        _scroll_picture.delegate_imageScroll = (id<WZProtocol_ImageScrollView>)_VC_main;
    }
}

#pragma mark Life cycle
- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

#pragma mark Public
- (void)matchingPicture:(UIImage *)image {
    [_scroll_picture matchingPicture:image];
}

@end
