//
//  WZImagesBrowseToolView.h
//  WZPhotoPicker
//
//  Created by admin on 17/6/1.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol WZProtocol_imagesBrowseToolView <NSObject>



@end

@interface WZImagesBrowseToolView : UIView

@property (nonatomic, strong) UIButton *button_left;
@property (nonatomic, strong) UIButton *button_right;

@end
