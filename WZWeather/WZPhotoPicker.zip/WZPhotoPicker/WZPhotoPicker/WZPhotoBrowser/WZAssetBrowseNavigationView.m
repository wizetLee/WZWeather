//
//  WZAssetBrowseNavigationView.m
//  WZPhotoPicker
//
//  Created by wizet on 2017/6/2.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "WZAssetBrowseNavigationView.h"

@implementation WZAssetBrowseNavigationView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
