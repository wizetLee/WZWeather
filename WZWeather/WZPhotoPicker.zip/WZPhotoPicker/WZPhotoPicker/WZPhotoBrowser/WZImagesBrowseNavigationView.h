//
//  WZImagesBrowseNavigationView.h
//  WZPhotoPicker
//
//  Created by admin on 17/6/1.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import <UIKit/UIKit.h>
@class WZImagesBrowseNavigationView;
@protocol WZProtocol_imagesBrowseNavigationView <NSObject>

- (void)leftButtunAction;
- (void)rightButtunAction;

@end

@interface WZImagesBrowseNavigationView : UIView
@property (nonatomic, weak) id<WZProtocol_imagesBrowseNavigationView> delegate;
@property (nonatomic, strong) UIButton *button_left;
@property (nonatomic, strong) UIButton *button_right;
@property (nonatomic, strong) UILabel *label_title;

@end
