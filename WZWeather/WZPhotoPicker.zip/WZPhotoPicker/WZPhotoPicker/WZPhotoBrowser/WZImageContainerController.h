//
//  WZImageContainerController.h
//  WZPhotoPicker
//
//  Created by admin on 17/5/24.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WZImageScrollView.h"

@class WZImageContainerController;
@protocol WZProtocol_ImageContainer <NSObject>

- (void)imageContainerController:(WZImageContainerController *)VC browseOrigionInIndex:(NSInteger)index;

@end

@interface WZImageContainerController : UIViewController

@property (nonatomic, weak) UIViewController *VC_main;
@property (nonatomic, weak) id<WZProtocol_ImageContainer> delegate;
@property (nonatomic, strong) UIButton *button_browseOrigion;
@property (nonatomic, assign) NSInteger integer_index;

- (void)matchingPicture:(UIImage *)image;

@end
