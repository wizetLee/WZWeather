//
//  WZImagesBrowseController.m
//  WZPhotoPicker
//
//  Created by admin on 17/5/24.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "WZImagesBrowseController.h"


#define WZRGBColor(r, g, b)  [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1.0]
#define WZRandomColor WZRGBColor(arc4random_uniform(256),arc4random_uniform(256),arc4random_uniform(256))

#pragma mark WZImagesBrowseController
@interface WZImagesBrowseController ()<
UIPageViewControllerDataSource,
UIPageViewControllerDelegate,
UIViewControllerTransitioningDelegate
>

@end

@implementation WZImagesBrowseController

- (instancetype)initWithTransitionStyle:(UIPageViewControllerTransitionStyle)style navigationOrientation:(UIPageViewControllerNavigationOrientation)navigationOrientation options:(NSDictionary<NSString *,id> *)options {
    NSMutableDictionary *configOptions = [NSMutableDictionary dictionaryWithDictionary:options?:@{}];
    //页面间隔设置
    configOptions[UIPageViewControllerOptionInterPageSpacingKey] = @(10);
    if (self = [super initWithTransitionStyle:UIPageViewControllerTransitionStyleScroll navigationOrientation:navigationOrientation options:configOptions]) {
        //自定义模态跳转模式
//        self.modalPresentationStyle = UIModalPresentationCustom;
        //模态过渡模式
        self.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        /*
         UIModalTransitionStyleCoverVertical：画面从下向上徐徐弹出，关闭时向下隐 藏（默认方式）。
         UIModalTransitionStyleFlipHorizontal：从前一个画面的后方，以水平旋转的方式显示后一画面。
         UIModalTransitionStyleCrossDissolve：前一画面逐渐消失的同时，后一画面逐渐显示。
         */
        //自定义跳转代理
//        self.transitioningDelegate = self;
        _integer_currentIndex = 0;
//        _numberOfIndexs = 9;
////        _datas
//        NSMutableArray *array = [NSMutableArray array];
//        for (int i = 0; i< 10; i++) {
//            WZMediaAsset *asset = [[WZMediaAsset alloc] init];
//            asset.name = [NSString stringWithFormat:@"我是%d号",i];
//            [array addObject:asset];
//        }
//        _datas = [NSArray arrayWithArray:array];
    }
    return self;
}

#pragma mark Life cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.automaticallyAdjustsScrollViewInsets = false;
    self.dataSource = self;
    self.delegate = self;
    [self createViews];
}

- (void)createViews {
    [self.view addSubview:self.custom_navigation];
}

#pragma mark WZProtocol_imagesBrowseNavigationView
- (void)leftButtunAction {
    [self dismissViewControllerAnimated:true completion:^{}];
}
- (void)rightButtunAction {
}

#pragma mark Match VC use index
- (WZImageContainerController *)matchControllerIndexWithIndex:(NSInteger)index {

    if (index < 0
        || index > _interger_numberOfIndexs) {
        return nil;
    }
   
    WZImageContainerController *VC = self.array_reuseable_imageContainers[index % self.array_reuseable_imageContainers.count];
    VC.integer_index = index;
    [self matchThumnailImageWith:VC];
    return VC;
}

#pragma mark Show VC in index
- (void)showInIndex:(NSInteger)index withAnimated:(BOOL)animated {
  
    if (index <= 0) {index = 0;}
    if (index > _interger_numberOfIndexs) {index = _interger_numberOfIndexs;}
    _integer_currentIndex  = index;
    
    WZImageContainerController *VC = [self matchControllerIndexWithIndex:_integer_currentIndex];
    [self matchOrigionImageWith:VC];
    [self setViewControllers:@[VC] direction:UIPageViewControllerNavigationDirectionForward animated:animated completion:^(BOOL finished) {
    }];
}


#pragma mark Match image
- (void)matchThumnailImageWith:(WZImageContainerController *)VC {
    if (!VC) {
        return;
    }
    
    NSUInteger index = VC.integer_index;
    
    if (index < _array_mediaAsset.count ) {
        WZMediaAsset *asset = _array_mediaAsset[index];
        if (asset.image_thumbnail) {
            [VC matchingPicture:asset.image_thumbnail];
        } else {
            [WZMediaPicker fetchThumbnailWith:asset.asset synchronous:false handler:^(UIImage *thumbnail) {
                asset.image_thumbnail = thumbnail;
                [VC matchingPicture:asset.image_thumbnail];
            }];
        }
        
        //        VC.button_browseOrigion.hidden = false;
    }
}

- (void)matchOrigionImageWith:(WZImageContainerController *)VC {
    if (!VC) {
        return;
    }
    NSUInteger index = VC.integer_index;
    WZMediaAsset *asset = nil;
    if (index < _array_mediaAsset.count ) {
        
        asset = _array_mediaAsset[index];
        if (asset.url_media) {
            //网络图片路径
            //直接使用 SD  抛出进度
            if (!_imageView_medium) {
                _imageView_medium = [[UIImageView alloc] init];
            }
            //cancel之前的下载
            [_imageView_medium sd_cancelCurrentImageLoad];
            [_imageView_medium sd_setImageWithPreviousCachedImageWithURL:asset.url_media andPlaceholderImage:nil options:SDWebImageRetryFailed progress:^(NSInteger receivedSize, NSInteger expectedSize) {
                //                VC中的加载动作
            } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                [VC matchingPicture:image];
            }];
            
        } else if (asset.string_origionPath || asset.image_origion) {
            if (asset.image_origion) {
                [VC matchingPicture:asset.image_origion];
            } else {
                UIImage *image = [UIImage imageWithContentsOfFile:asset.string_origionPath];
                [VC matchingPicture:image];
            }
        } else if (asset.asset) {
            //根据 PHAsset callback
            //block回调可能会引起图片紊乱  请求前先将之前的request cancel掉
            [[PHImageManager defaultManager] cancelImageRequest:_imageRequestID];
            
            //            if (asset.showOrigion) {
            //                _imageRequestID = [WZMediaPicker fetchOrigionWith:asset.asset synchronous:false handler:^(UIImage *origion) {
            //                    //图片有时候像素太高 渲染成本太高 作判断压缩降低成本
            //                    [VC matchingPicture:origion];
            //                }];
            //            } else {
            _imageRequestID = [WZMediaPicker fetchImageWith:asset.asset costumSize:CGSizeMake(2000, 2000) synchronous:false handler:^(UIImage *image) {
                //                asset.image_origion = image;//不作缓存
                [VC matchingPicture:image];
            }];
            //            }
        }
    }
    
    //配置其他的属性
    self.custom_navigation.label_title.text = [NSString stringWithFormat:@"当前页面ID:%ld", index];
    self.mediaAsset_current = asset;
}

#pragma mark WZProtocol_ImageScrollView
- (void)singleTap {
    self.custom_navigation.hidden = !self.custom_navigation.hidden;
}
- (void)doubleTap {
    
}
- (void)longPress {
    
}


#pragma mark UIPageViewControllerDelegate
- (void)pageViewController:(UIPageViewController *)pageViewController didFinishAnimating:(BOOL)finished previousViewControllers:(NSArray<UIViewController *> *)previousViewControllers transitionCompleted:(BOOL)completed {
    WZImageContainerController *VC = pageViewController.viewControllers.firstObject;
    [self matchOrigionImageWith:VC];
}

#pragma mark UIPageViewControllerDataSource
- (nullable UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(WZImageContainerController *)viewController {
    return [self matchControllerIndexWithIndex:viewController.integer_index - 1];
}

- (nullable UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(WZImageContainerController *)viewController {
    return [self matchControllerIndexWithIndex:viewController.integer_index + 1];
}

#pragma mark UIViewControllerTransitioningDelegate
- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source {
    
    return nil;
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    return nil;
}

#pragma mark WZProtocol_ImageContainer
- (void)imageContainerController:(WZImageContainerController *)VC browseOrigionInIndex:(NSInteger)index {
    //查看源图动作
    if (index < _array_mediaAsset.count ) {
        WZMediaAsset *asset = _array_mediaAsset[index];
        //loading begin
        [WZMediaPicker fetchOrigionWith:asset.asset synchronous:true handler:^(UIImage *origion) {
        //loading end
            [VC matchingPicture:origion];
//            asset.showOrigion = true;
//            VC.button_browseOrigion.hidden = true;
        }];
    }
}

#pragma mark Accessor
- (NSArray <WZImageContainerController *>*)array_reuseable_imageContainers {
    if (!_array_reuseable_imageContainers) {
        NSMutableArray *tmpMArr = [NSMutableArray array];
        NSUInteger reuseCount = 5;
        for (NSUInteger i = 0; i < reuseCount; i++) {
            WZImageContainerController *VC = [[WZImageContainerController alloc] init];
            VC.integer_index = i;
            VC.delegate = (id<WZProtocol_ImageContainer>)self;
            VC.VC_main = self;
            [tmpMArr addObject:VC];
        }
        _array_reuseable_imageContainers = [NSArray arrayWithArray:tmpMArr];
    }
    return _array_reuseable_imageContainers;
}

- (void)setArray_mediaAsset:(NSArray<WZMediaAsset *> *)array_mediaAsset {
    if ([array_mediaAsset isKindOfClass:[NSArray class]]) {
        _array_mediaAsset = array_mediaAsset;
        _interger_numberOfIndexs = _array_mediaAsset.count - 1;
    }
}

- (WZImagesBrowseNavigationView *)custom_navigation {
    if (!_custom_navigation) {
        _custom_navigation = [[WZImagesBrowseNavigationView alloc] initWithFrame:CGRectZero];
        _custom_navigation.delegate = (id<WZProtocol_imagesBrowseNavigationView>)self;
    }
    return _custom_navigation;
}

@end
