//
//  WZRemoteImageNavigationView.h
//  WZPhotoPicker
//
//  Created by admin on 17/6/9.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "WZAssetBrowseNavigationView.h"

@interface WZRemoteImageNavigationView : WZAssetBrowseNavigationView

@end
