//
//  WZImagesBrowseController.h
//  WZPhotoPicker
//
//  Created by admin on 17/5/24.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WZImageContainerController.h"

/*
    URL数组
    image数组
    PHAsset数组
    | |
     |
    WZMediaAsset数组
 */

@interface WZImagesBrowseController : UIPageViewController

@property (nonatomic, strong) NSArray <WZMediaAsset *> *array_mediaAsset;

- (void)showInIndex:(NSInteger)index withAnimated:(BOOL)animated;

@end
