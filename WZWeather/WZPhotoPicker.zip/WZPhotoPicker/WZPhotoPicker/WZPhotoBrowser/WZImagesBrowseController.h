//
//  WZImagesBrowseController.h
//  WZPhotoPicker
//
//  Created by admin on 17/5/24.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WZImageContainerController.h"

#import "UIImageView+WebCache.h"
#import "WZImagesBrowseNavigationView.h"
#import "WZImagesBrowseToolView.h"
/*
    URL数组
    image数组
    PHAsset数组
    | |
     |
    WZMediaAsset数组
 */

@interface WZImagesBrowseController : UIPageViewController

@property (nonatomic, strong) NSArray <WZMediaAsset *> *array_mediaAsset;


@property (nonatomic, strong) NSArray<WZImageContainerController *> *array_reuseable_imageContainers;
@property (nonatomic, assign) NSInteger integer_currentIndex;
@property (nonatomic, assign) NSInteger interger_numberOfIndexs;
@property (nonatomic, assign) PHImageRequestID imageRequestID;

@property (nonatomic, strong) UIImageView *imageView_medium;

@property (nonatomic, strong) WZImagesBrowseNavigationView *custom_navigation;
@property (nonatomic, strong) WZImagesBrowseToolView *custom_tool;

@property (nonatomic, strong) WZMediaAsset *mediaAsset_current;//当前集合

- (void)showInIndex:(NSInteger)index withAnimated:(BOOL)animated;

@end
