////
////  WZPhotoBrowseController.h
////  WZPhotoPicker
////
////  Created by admin on 17/5/22.
////  Copyright © 2017年 wizet. All rights reserved.
////
//
//#import <UIKit/UIKit.h>
//#import "WZMediaAssetBaseCell.h"
//
//@interface WZPhotoBrowseCell : WZMediaAssetBaseCell
//
//@end
//
//@interface WZPhotoBrowseController : UIViewController
//
//@property (nonatomic, strong) NSMutableArray <WZMediaAsset *> *assetMArray;
//
//@end
