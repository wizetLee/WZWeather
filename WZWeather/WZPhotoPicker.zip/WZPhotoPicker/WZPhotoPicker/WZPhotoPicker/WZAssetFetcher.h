//
//  WZAssetFetcher.h
//  WZPhotoPicker
//
//  Created by wizet on 2017/6/2.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WZAssetFetcher : NSObject

@end
