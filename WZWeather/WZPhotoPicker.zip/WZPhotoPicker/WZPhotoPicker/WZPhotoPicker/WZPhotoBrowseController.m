////
////  WZPhotoBrowseController.m
////  WZPhotoPicker
////
////  Created by admin on 17/5/22.
////  Copyright © 2017年 wizet. All rights reserved.
////
//
//#import "WZPhotoBrowseController.h"
//
//@implementation WZPhotoBrowseCell
//
//- (instancetype)initWithFrame:(CGRect)frame
//{
//    self = [super initWithFrame:frame];
//    if (self) {
//        
//    }
//    return self;
//}
//
//@end
//
//
//@interface WZPhotoBrowseController ()
//
//@property (nonatomic, strong) UICollectionView *collection;
//@property (nonatomic, assign) BOOL navigationBarOrigionHidden;
//
//@end
//
//@implementation WZPhotoBrowseController
//
//#pragma mark - ViewController Lifecycle
//
//+ (instancetype)showPhotoWithAssetArray:(NSMutableArray <WZMediaAsset *> *)assetMArray inIndex:(NSUInteger)index {
//    if ([assetMArray isKindOfClass:[NSArray class]] && assetMArray.count) {
//        WZPhotoBrowseController *VC = [[WZPhotoBrowseController alloc] init];
//        VC.assetMArray = assetMArray;
//        return VC;
//    } else {
//        return nil;
//    }
//}
//
//- (void)viewWillAppear:(BOOL)animated {
//    [super viewWillAppear:animated];
//    if (self.navigationController) {
//        _navigationBarOrigionHidden = self.navigationController.navigationBarHidden;
//        self.navigationController.navigationBarHidden = true;
//    }
//}
//
//- (void)viewDidLoad {
//    [super viewDidLoad];
//    self.view.backgroundColor = [UIColor yellowColor];
//    self.title = NSStringFromClass([self class]);
//    self.automaticallyAdjustsScrollViewInsets = false;
//    if (!_assetMArray) {
//        _assetMArray = [NSMutableArray array];
//    }
//    [self createViews];
//}
//
//- (void)viewWillDisappear:(BOOL)animated {
//    [super viewWillDisappear:animated];
//    if (self.navigationController) {
//        self.navigationController.navigationBarHidden = _navigationBarOrigionHidden;
//    }
//}
//
//- (void)didReceiveMemoryWarning {
//    [super didReceiveMemoryWarning];
//}
//
//- (void)dealloc {
//    NSLog(@"%s", __func__);
//}
//
//#pragma mark Detail
//
//- (void)createViews {
//    [self.view addSubview:self.collection];
//}
//
//#pragma mark setter & getter
//- (UICollectionView *)collection {
//    if (!_collection) {
//        CGFloat gapBetweenPhoto = 10.0;
//        CGRect rect = self.navigationController?CGRectMake(0.0, 64.0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height - 64.0):self.view.bounds;
//        
//        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
//        
//        CGFloat itemW = [UIScreen mainScreen].bounds.size.width + gapBetweenPhoto;
//        CGFloat itemH = [UIScreen mainScreen].bounds.size.height;
//        layout.itemSize = CGSizeMake(itemW, itemH);
//        
//        _collection = [[UICollectionView alloc] initWithFrame:rect collectionViewLayout:layout];
//        _collection.backgroundColor = [UIColor whiteColor];
//        _collection.dataSource = (id<UICollectionViewDataSource>)self;
//        _collection.delegate = (id<UICollectionViewDelegate>)self;
//        _collection.pagingEnabled = true;
//        [_collection registerClass:[WZMediaAssetBaseCell class]
//        forCellWithReuseIdentifier:NSStringFromClass([WZMediaAssetBaseCell class])];
//    }
//    return _collection;
//}
//
//@end
