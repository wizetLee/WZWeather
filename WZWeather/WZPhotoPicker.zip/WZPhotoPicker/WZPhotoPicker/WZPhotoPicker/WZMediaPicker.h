//
//  WZPhotoPicker.h
//  WZPhotoPicker
//
//  Created by wizet on 2017/5/19.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Photos/Photos.h>
#import "NSObject+WZCommon.h"
#import "NSObject+file.h"

@class WZMediaAsset;
@protocol WZMediaProtocol <NSObject>

@optional

- (void)pickerAssets:(NSArray <WZMediaAsset *> *)assets;

//同步获取图片数据 thumnail | origion + loading + end + callback
- (void)pickerOrigionArray:(NSArray <UIImage *>*)origionArray thumnailArray:(NSArray <UIImage *>*)thumnailArray;

@end

typedef NS_ENUM(NSUInteger, WZMediaType) {
    WZMediaType_unknow = 0,
    WZMediaType_photo = 1,
    WZMediaType_video = 2,
    WZMediaType_audio = 3,
};

@interface WZMediaAsset : NSObject

@property (nonatomic, assign) BOOL selected;
//@property (nonatomic, assign) BOOL showOrigion;
@property (nonatomic, strong) PHAsset *asset;//未释放前有效
@property (nonatomic, assign) WZMediaType mediaType;

@property (nonatomic, strong) UIImage *image_thumbnail;
@property (nonatomic, strong) NSURL *url_media;

//不建议使用的属性
@property (nonatomic, strong) NSString *string_origionPath;
//mediaType == WZMediaType_photo
@property (nonatomic, strong) UIImage *image_origion;


//同\异步回调
- (void)fetchThumbnailImageSynchronous:(BOOL)synchronous handler:(void (^)(UIImage *image))handler;
- (void)fetchOrigionImageSynchronous:(BOOL)synchronous handler:(void (^)(UIImage *image))handler;

@end

@interface WZMediaAssetCollection : NSObject

@property (nonatomic, strong) NSArray <WZMediaAsset *>* array_mediaAsset;
@property (nonatomic, strong) PHAssetCollection *assetCollection;
@property (nonatomic, strong) NSString *string_title;
@property (nonatomic, strong) WZMediaAsset *coverAssset;//默认是 assetMArray 首个元素

//自定义封面
- (void)customCoverWithMediaAsset:(WZMediaAsset *)mediaAsset withCoverHandler:(void(^)(UIImage *image))handler;
//默认封面
- (void)coverHandler:(void(^)(UIImage *image))handler;

@end

@interface WZMediaPicker : NSObject

/**
 *   照片数据源获取
 *
 *  @return  数据源集合
 */
+ (NSMutableArray <WZMediaAssetCollection *> *)fetchAssetCollection;

#pragma mark 同步/异步获取图片
/**
 *  获取asset的缩略图
 *
 *  @param mediaAsset PHAsset
 *  @param handler    返回一张缩略图
 *  @return  ID
 */
+ (int32_t)fetchThumbnailWith:(PHAsset *)mediaAsset synchronous:(BOOL)synchronous handler:(void(^)(UIImage *thumbnail))handler ;

/**
 *  获取asset的源图
 *
 *  @param mediaAsset PHAsset
 *  @param handler    返回 原始图片
 *  @return  ID
 */
+ (int32_t)fetchOrigionWith:(PHAsset *)mediaAsset synchronous:(BOOL)synchronous handler:(void(^)(UIImage *origion))handler;

//自定义规格的图片
+ (int32_t)fetchImageWith:(PHAsset *)mediaAsset costumSize:(CGSize)customSize synchronous:(BOOL)synchronous handler:(void(^)(UIImage *origion))handler;

@end
