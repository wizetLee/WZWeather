//
//  WZAssetFetcher.m
//  WZPhotoPicker
//
//  Created by wizet on 2017/6/2.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "WZAssetFetcher.h"

@implementation WZAssetFetcher

@end
