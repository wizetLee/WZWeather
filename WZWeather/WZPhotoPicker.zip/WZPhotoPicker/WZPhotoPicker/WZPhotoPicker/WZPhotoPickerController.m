//
//  WZPhotoPickerController.m
//  WZPhotoPicker
//
//  Created by wizet on 2017/5/19.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "WZPhotoPickerController.h"
#import "WZMediaAssetBaseCell.h"
#import "WZImagesBrowseController.h"

#pragma mark WZPhotoPickerController
@interface WZPhotoPickerController ()
<UICollectionViewDelegate
, UICollectionViewDataSource
, UICollectionViewDelegateFlowLayout>

@property (nonatomic, strong) UICollectionView *collection;
@property (nonatomic, strong) NSMutableArray <WZMediaAsset *> *mArray_mediaAsset_callback;

@end

@implementation WZPhotoPickerController

#pragma mark initialize
+ (void)showPickerWithPresentedController:(UIViewController *)presentedController {
    WZPhotoPickerController *pickerVC = [[WZPhotoPickerController alloc] init];
    UINavigationController *navigationVC = [[UINavigationController alloc] initWithRootViewController:pickerVC];
    [presentedController presentViewController:navigationVC animated:true completion:^{
    }];
}

#pragma mark - ViewController Lifecycle
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor yellowColor];
    self.title = NSStringFromClass([self class]);
    self.automaticallyAdjustsScrollViewInsets = false;
    if (!_array_mediaAsset) {
        _array_mediaAsset = [NSArray array];
    }
    _mArray_mediaAsset_callback = [NSMutableArray array];
    [self createViews];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)dealloc {
    NSLog(@"%s", __func__);
}

#pragma mark create views
- (void)createViews {
    [self.view addSubview:self.collection];
    UIBarButtonItem *left = [[UIBarButtonItem alloc] initWithTitle:@"返回目录" style:UIBarButtonItemStyleDone target:self action:@selector(back)];
    UIBarButtonItem *right = [[UIBarButtonItem alloc] initWithTitle:@"选择完成" style:UIBarButtonItemStyleDone target:self action:@selector(finish)];
    
    if (self.navigationController) {
        self.navigationItem.leftBarButtonItem = left;
        self.navigationItem.rightBarButtonItem = right;
    }
}

- (void)finish {
    //如果实现了代理
    if ([_delegate respondsToSelector:@selector(pickerOrigionArray:thumnailArray:)]) {
        //获取选中目标(_mArray_mediaAsset_callback)  同步取出大小图
        NSMutableArray *mArray_thumnail = [NSMutableArray array];
        NSMutableArray *mArray_origion = [NSMutableArray array];
        for (WZMediaAsset *mediaAsset in _mArray_mediaAsset_callback) {
            [mediaAsset fetchThumbnailImageSynchronous:true handler:^(UIImage *image) {
                [mArray_thumnail addObject:image];
            }];
            [mediaAsset fetchOrigionImageSynchronous:true handler:^(UIImage *image) {
                [mArray_origion addObject:image];
            }];
        }
        
        [_delegate pickerOrigionArray:mArray_origion thumnailArray:mArray_thumnail];
        //同步完
        [self dismiss];
    } else {
        [self dismiss];
    }
}

- (void) dismiss{
    [self dismissViewControllerAnimated:true completion:^{
        if ([_delegate respondsToSelector:@selector(pickerAssets:)]) {
            [_delegate pickerAssets:[NSArray arrayWithArray:_mArray_mediaAsset_callback]];
        }
    }];
}

-(void)back {
    if (self.navigationController) {
        [self.navigationController popViewControllerAnimated:true];
    } else {
        [self dismissViewControllerAnimated:true completion:^{}];
    }
}

#pragma mark UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _array_mediaAsset.count;
}

- (__kindof WZMediaAssetBaseCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    __block WZMediaAssetBaseCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([WZMediaAssetBaseCell class]) forIndexPath:indexPath];
    
    @try {
        cell.asset = _array_mediaAsset[indexPath.row];
        __weak typeof(self) weakSelf = self;
        cell.selectedBlock = ^(BOOL selected) {
            WZMediaAsset *asset = weakSelf.array_mediaAsset[indexPath.row];
            if ([weakSelf.mArray_mediaAsset_callback containsObject:asset]) {
                [weakSelf.mArray_mediaAsset_callback removeObject:asset];
            } else {
                [weakSelf.mArray_mediaAsset_callback addObject:asset];
            }
        };
        
    } @catch (NSException *exception) {
        
    }
    return cell;
}

#pragma mark UICollectionViewDelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
//    WZMediaAssetBaseCell *cell = (WZMediaAssetBaseCell *)[collectionView cellForItemAtIndexPath:indexPath];

    //浏览大图
    WZImagesBrowseController *VC = [[WZImagesBrowseController alloc] init];
    VC.array_mediaAsset = self.array_mediaAsset;
    [VC showInIndex:indexPath.row withAnimated:true];
    [self presentViewController:VC animated:true completion:^{}];
}

#pragma mark WZMediaProtocol
- (void)pickerAssets:(NSArray <WZMediaAsset *> *)assets {
    if (assets) {
        [_mArray_mediaAsset_callback addObjectsFromArray:assets];
    }
}

#pragma mark Accessor
- (void)setArray_mediaAsset:(NSArray<WZMediaAsset *> *)array_mediaAsset {
    _array_mediaAsset = [array_mediaAsset isKindOfClass:[NSArray class]]?array_mediaAsset:nil;
    if (_collection) {
        [_collection reloadData];
    }
}

- (UICollectionView *)collection {
    if (!_collection) {
        CGRect rect = self.navigationController?CGRectMake(0.0, 64.0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height - 64.0):self.view.bounds;
        
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        CGFloat gap = 10.0;
        layout.minimumLineSpacing = gap;
        layout.minimumInteritemSpacing = gap;
        layout.sectionInset = UIEdgeInsetsMake(gap, gap, gap, gap);
        CGFloat itemWH = ([UIScreen mainScreen].bounds.size.width - gap * 5) / 4;
        layout.itemSize = CGSizeMake(itemWH, itemWH);
        
        _collection = [[UICollectionView alloc] initWithFrame:rect collectionViewLayout:layout];
        _collection.backgroundColor = [UIColor whiteColor];
        _collection.dataSource = self;
        _collection.delegate = self;
        [_collection registerClass:[WZMediaAssetBaseCell class] forCellWithReuseIdentifier:NSStringFromClass([WZMediaAssetBaseCell class])];
    }
    return _collection;
}


@end
