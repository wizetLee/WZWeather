//
//  ViewController.m
//  WZPhotoPicker
//
//  Created by wizet on 2017/5/19.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "ViewController.h"
#import "WZPhotoCatalogueController.h"
#import "WZMediaPicker.h"

@interface ViewController ()<WZMediaProtocol>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [NSObject requestPhotosLibraryAuthorization:nil];
    UIButton *button = [[UIButton alloc] init];
    button.frame = self.view.bounds;
    [button addTarget:self action:@selector(clickedBtn:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
}

- (void)clickedBtn:(UIButton *)sender {
    [WZPhotoCatalogueController showPickerWithPresentedController:self];
}

#pragma mark WZMediaProtocol

- (void)pickerAssets:(NSArray <WZMediaAsset *> *)assets {
    if (assets) {
    }
}

- (void)pickerOrigionArray:(NSArray <UIImage *>*)origionArray thumnailArray:(NSArray <UIImage *>*)thumnailArray {
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
