//
//  ViewController.m
//  WZPhotoPicker
//
//  Created by wizet on 2017/5/19.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "ViewController.h"
#import "WZPhotoCatalogueController.h"
#import "WZMediaFetcher.h"
#import "WZRemoteImageBrowseController.h"

@interface ViewController ()<WZProtocol_mediaAsset>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [NSObject requestPhotosLibraryAuthorization:nil];
    UIButton *button = [[UIButton alloc] init];
    button.frame = self.view.bounds;
    [button addTarget:self action:@selector(clickedBtn:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
}

- (void)clickedBtn:(UIButton *)sender {
//    [WZPhotoCatalogueController showPickerWithPresentedController:self];
    
//    NSArray <NSString *>*array_images = @[
//                              @"http://img.article.pchome.net/00/25/51/47/pic_lib/wm/huangshi31.jpg",
//                              @"http://www.taketours.cn/images/v260486/yellowstone.JPG",
//                              @"http://www.5fen.com/uploads/allimg/131215/98-131215160J50-L.png",
//                              @"http://pic6.nipic.com/20100305/3648835_130246001000_2.jpg",
//                              @"http://www.meijialx.com/UserFiles/5(1463).jpg",
//                              @"http://pic13.nipic.com/20110308/5754245_080416078000_2.jpg",
//                              @"http://pic4.nipic.com/20091202/753913_193359691330_2.jpg",
//                              @"http://pic25.nipic.com/20121210/7447430_215257628000_2.jpg",
//                              @"http://fj2.eastday.com/hdqxb2013/20130823_7/node757990/images/02347082.jpg",
//                              @"http://www.ovoschooling.com/UploadFile/486072.jpg",
//                              @"http://tse3.mm.bing.net/th?id=OIP.OVq4ZcSfgO0FTwlX7_LmLAEsC7&pid=15.1",
//                              @"http://www.chinanews.com/tp/hd2011/2013/06-05/U508P4T426D210589F16470DT20130605152842.jpg",
//                              @"http://photo.workercn.cn/html/files/2014-05/09/20140509113225015592189.jpg",
//                              @"http://image.xinmin.cn/2013/07/30/20130730082617093478.jpg",
//                              @"http://www.chinanews.com/tp/hd2011/2013/08-28/U508P4T426D240266F16470DT20130828154442.jpg",
//                              @"http://www.yeeed.com/wp-content/uploads/2014/03/ZhongGuo-14.jpg",
//                              @"http://finance.chinanews.com/life/hd/2013/07-01/U287P51T16D13832F435DT20130701161234.jpg",
//                              @"http://finance.chinanews.com/life/hd/2013/10-10/U217P51T16D14283F435DT20131010144853.jpg",
//                              @"http://finance.chinanews.com/life/hd/2013/10-10/U217P51T16D14270F435DT20131010134051.jpg",
//                              @"http://www.chinanews.com/tp/hd2011/2013/09-26/U508P4T426D249631F16470DT20130926153638.jpg",
//                              @"http://i2.chinanews.com/simg/hd/2014/05/09/5c8f0ca41814401db1b5f31309c9b086.jpg",
//                              @"http://imgbdb2.bendibao.com/guangzhou/20136/28/2013628155018139.jpg",
//                              @"http://i2.chinanews.com/simg/hd/2014/05/09/d773e709dc684ea5913fdd2427cab648.jpg",
//                              @"http://imgbdb2.bendibao.com/guangzhou/20136/28/2013628155016436.jpg",];
//   
//    NSArray <NSURL *>*mArray_url = [WZRemoteImageBrowseController fetchUrlArrayAccordingStringArray:array_images];
//    [WZRemoteImageBrowseController showRemoteImagesWithURLArray:mArray_url loactedVC:self];
    
   
    
}

#pragma mark WZMediaProtocol

- (void)fetchAssets:(NSArray <WZMediaAsset *> *)assets {
    if (assets) {
    }
}

- (void)pickerOrigionArray:(NSArray <UIImage *>*)origionArray thumnailArray:(NSArray <UIImage *>*)thumnailArray {
    
}

@end
