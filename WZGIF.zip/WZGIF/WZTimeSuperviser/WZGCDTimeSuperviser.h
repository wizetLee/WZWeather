//
//  WZGCDTimeSuperviser.h
//  WZWeather
//
//  Created by wizet on 17/5/6.
//  Copyright © 2017年 WZ. All rights reserved.
//

#import "WZTimeSuperviser.h"

@interface WZGCDTimeSuperviser : WZTimeSuperviser

@end
